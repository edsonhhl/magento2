require(['jquery', 'bizkickowlcarousel'], function() {
    jQuery(document).ready(function() {
        jQuery(".home-slider").owlCarousel({
            items: 1,
            itemsDesktop: [1198, 1],
            itemsDesktopSmall: [1023, 1],
            itemsTablet: [768, 1],
            itemsTabletSmall: [767, 1],
            itemsMobile: [479, 1],
            pagination: true,
            navigationText: ["<div class='left-arrow'><i class='fa fa-angle-left'></i></div>", "<div class='right-arrow'><i class='fa fa-angle-right'></div>"],
            navigation: true,
        });
        jQuery(".home-slider li").show();
    });
});
