<?php

/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Dot\Bizkick\Setup;

use Magento\Framework\Setup;

class Installer implements Setup\SampleData\InstallerInterface {

    /**
     * @var \Magento\CmsSampleData\Model\Page
     */
    private $page;

    /**
     * @var \Magento\CmsSampleData\Model\Block
     */
    private $block;

    /**
     * @param \Dot\Bizkick\Model\Page $page
     * @param \Dot\Bizkick\Model\Block $block
     */
    public function __construct(
    \Dot\Bizkick\Model\Page $page, 
            \Dot\Bizkick\Model\Block $block
    ) {
        $this->page = $page;
        $this->block = $block;
    }

    /**
     * {@inheritdoc}
     */
    public function install() {

        //$this->page->install(['Dot_Bizkick::fixtures/pages/pages.csv']);
        $this->page->install(
                [

                    'Dot_Bizkick::DemoPages/pages.csv',
                ]
        );
        $this->block->install(
                [

                    'Dot_Bizkick::DemoBlocks/blocks.csv',
                ]
        );
    }

}
