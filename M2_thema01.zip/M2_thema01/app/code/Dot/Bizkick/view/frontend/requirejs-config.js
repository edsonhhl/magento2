var config = {
    map: {
        '*': {
            bizkickowlcarousel: 'Dot_Bizkick/js/owl.carousel',
        }
    }
};